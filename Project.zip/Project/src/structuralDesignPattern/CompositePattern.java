package structuralDesignPattern;
import java.util.ArrayList;
import java.util.List;

interface CartItem {

    double getPrice();

    void display();
}

class Product implements CartItem {

    private String name;
    private double price;

    public Product(String name,double price) {
        this.name = name;
        this.price = price;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public void display() {
        System.out.println("Product : "
                + name + " ₹" + price);
    }
}

class ProductBundle implements CartItem {

    private String bundleName;

    private List<CartItem> items =
            new ArrayList<>();

    public ProductBundle(String bundleName) {
        this.bundleName = bundleName;
    }

    public void addItem(CartItem item) {
        items.add(item);
    }

    @Override
    public double getPrice() {

        double total = 0;

        for(CartItem item : items) {
            total += item.getPrice();
        }

        return total;
    }

    @Override
    public void display() {

        System.out.println("Bundle : "
                + bundleName);

        for(CartItem item : items) {
            item.display();
        }
    }
}

public class CompositePattern {

    public static void main(String[] args) {

        CartItem book =
                new Product("Book",500);

        CartItem pen =
                new Product("Pen",20);

        CartItem notebook =
                new Product("Notebook",50);

        ProductBundle schoolKit =
                new ProductBundle("School Kit");

        schoolKit.addItem(pen);
        schoolKit.addItem(notebook);

        List<CartItem> cart =
                new ArrayList<>();

        cart.add(book);
        cart.add(schoolKit);

        double total = 0;

        for(CartItem item : cart) {

            item.display();

            total += item.getPrice();
        }

        System.out.println("Total = " + total);
    }
}

// problem code here that we solve above
/*
class Product {

    private String name;
    private double price;

    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public void display() {
        System.out.println("Product : " + name + " ₹" + price);
    }
}

class ProductBundle {

    private String bundleName;
    private List<Product> products = new ArrayList<>();

    public ProductBundle(String bundleName) {
        this.bundleName = bundleName;
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public double getPrice() {

        double total = 0;

        for(Product product : products) {
            total += product.getPrice();
        }

        return total;
    }

    public void display() {

        System.out.println("Bundle : " + bundleName);

        for(Product product : products) {
            product.display();
        }
    }
}

public class Main {

    public static void main(String[] args) {

        Product book = new Product("Book",500);

        Product phone = new Product("Phone",80000);
        Product charger = new Product("Charger",2000);

        ProductBundle phoneCombo =
                new ProductBundle("Phone Combo");

        phoneCombo.addProduct(phone);
        phoneCombo.addProduct(charger);

        List<Object> cart = new ArrayList<>();

        cart.add(book);
        cart.add(phoneCombo);

        double total = 0;

        for(Object item : cart) {

            if(item instanceof Product) {

                Product p = (Product)item;

                p.display();

                total += p.getPrice();
            }

            else if(item instanceof ProductBundle) {

                ProductBundle bundle =
                        (ProductBundle)item;

                bundle.display();

                total += bundle.getPrice();
            }
        }

        System.out.println("Total = " + total);
    }
}

*/
