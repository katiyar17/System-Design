package structuralDesignPattern;

import java.util.HashMap;
import java.util.Map;

interface VideoDownloader {
    String downloadVideo(String videoUrl);
}

class RealVideoDownloader implements VideoDownloader {

    @Override
    public String downloadVideo(String videoUrl) {
        System.out.println("Downloading video from : " + videoUrl);
        return "Video Content of " + videoUrl;
    }
}

class CachedVideoDownloader implements VideoDownloader {

    private RealVideoDownloader realVideoDownloader;
    Map<String, String> cache;

    public CachedVideoDownloader() {
        this.realVideoDownloader = new RealVideoDownloader();
        this.cache = new HashMap<>();
    }


    @Override
    public String downloadVideo(String videoUrl) {
         if (cache.containsKey(videoUrl)) {
             System.out.println("Returning Cached Video");
             return cache.get(videoUrl);
         }

        System.out.println("Cache Miss");
        String video = realVideoDownloader.downloadVideo(videoUrl);
        cache.put(videoUrl, video);
        return video;

    }
}


public class ProxyPattern {
    public static void main(String[] args) {
        VideoDownloader CachedVideoDownloader = new CachedVideoDownloader();
        CachedVideoDownloader.downloadVideo("pat");
        CachedVideoDownloader.downloadVideo("pat");


    }
}
