package structuralDesignPattern;

interface PaymentGateway {
    void pay(String orderId, double amount);
}

class PayU implements PaymentGateway {

    @Override
    public void pay(String orderId, double amount) {
        System.out.println("Payment made through PayU");
    }
}

// not implementing the paymentGateway we need make its adapter to call pay of this
class RazorPayApi {
    public void pay(String orderId, double amount) {
        System.out.println("Payment made through RazorPay");
    }
}

// like this we can add multiple adapter classes here for multiple new Apis
class RazorPayAdapter implements PaymentGateway {

    private RazorPayApi razorPayApi;

    public RazorPayAdapter() {
        this.razorPayApi = new RazorPayApi();
    }

    @Override
    public void pay(String orderId, double amount) {
       razorPayApi.pay(orderId, amount);
    }
}

class CheckOutService {

    private PaymentGateway paymentGateway;

    public CheckOutService(PaymentGateway paymentGateway) {
        this.paymentGateway = paymentGateway;
    }

    public void checkOut(String orderId, double amount) {
        paymentGateway.pay(orderId, amount);
    }

}

public class AdapterPattern {
    public static void main(String[] args) {

        CheckOutService checkOutService = new CheckOutService(new RazorPayAdapter());
        checkOutService.checkOut("321",222222222.00);

    }
}
