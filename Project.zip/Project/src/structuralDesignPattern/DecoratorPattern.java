package structuralDesignPattern;

// ================= COMPONENT =================

interface Pizza {
    String getDescription();
    double getCost();
}

// ================= CONCRETE COMPONENTS =================

class PlainPizza implements Pizza {

    @Override
    public String getDescription() {
        return "Plain Pizza";
    }

    @Override
    public double getCost() {
        return 150.0;
    }
}

class MargheritaPizza implements Pizza {

    @Override
    public String getDescription() {
        return "Margherita Pizza";
    }

    @Override
    public double getCost() {
        return 200.0;
    }
}

// ================= DECORATOR =================

abstract class PizzaDecorator implements Pizza {

    protected Pizza pizza;

    public PizzaDecorator(Pizza pizza) {
        this.pizza = pizza;
    }
}

// ================= CONCRETE DECORATORS =================

class ExtraCheese extends PizzaDecorator {

    public ExtraCheese(Pizza pizza) {
        super(pizza);
    }

    @Override
    public String getDescription() {
        return pizza.getDescription() + ", Extra Cheese";
    }

    @Override
    public double getCost() {
        return pizza.getCost() + 40.0;
    }
}

class Olives extends PizzaDecorator {

    public Olives(Pizza pizza) {
        super(pizza);
    }

    @Override
    public String getDescription() {
        return pizza.getDescription() + ", Olives";
    }

    @Override
    public double getCost() {
        return pizza.getCost() + 30.0;
    }
}

class StuffedCrust extends PizzaDecorator {

    public StuffedCrust(Pizza pizza) {
        super(pizza);
    }

    @Override
    public String getDescription() {
        return pizza.getDescription() + ", Stuffed Crust";
    }

    @Override
    public double getCost() {
        return pizza.getCost() + 50.0;
    }
}

// ================= MAIN CLASS =================

public class DecoratorPattern {

    public static void main(String[] args) {

        // Base Pizza
        Pizza pizza = new MargheritaPizza();

        // Add Extra Cheese
        pizza = new ExtraCheese(pizza);

        // Add Olives
        pizza = new Olives(pizza);

        // Add Stuffed Crust
        pizza = new StuffedCrust(pizza);

        // Final Output
        System.out.println("Description : " + pizza.getDescription());
        System.out.println("Total Cost  : ₹" + pizza.getCost());
    }
}