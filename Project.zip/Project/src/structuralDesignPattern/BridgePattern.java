package structuralDesignPattern;

interface VideoQuality {
    void load(String title);
}

class SDQuality implements VideoQuality {
    public void load(String title) {
        System.out.println("Streaming " + title + " in SD Quality");
    }
}

class HDQuality implements VideoQuality {
    public void load(String title) {
        System.out.println("Streaming " + title + " in HD Quality");
    }
}

class UltraHDQuality implements VideoQuality {
    public void load(String title) {
        System.out.println("Streaming " + title + " in UltraHD Quality");
    }
}

abstract class VideoPlayer {
    protected VideoQuality videoQuality;

    public VideoPlayer(VideoQuality videoQuality) {
        this.videoQuality = videoQuality;
    }

    public abstract void play(String title);
}

class WebPlayer extends VideoPlayer {

    public WebPlayer(VideoQuality videoQuality) {
        super(videoQuality);
    }

    @Override
    public void play(String title) {
        System.out.println("web Platform");
        videoQuality.load(title);
    }

}

class MobilePlayer extends VideoPlayer {

    public MobilePlayer(VideoQuality videoQuality) {
        super(videoQuality);
    }

    @Override
    public void play(String title) {
        System.out.println("mobile Platform");
        videoQuality.load(title);
    }
}


public class BridgePattern {
    public static void main(String[] args) {

        VideoPlayer webPlayer = new WebPlayer(new UltraHDQuality());
        webPlayer.play("title");


    }
}
