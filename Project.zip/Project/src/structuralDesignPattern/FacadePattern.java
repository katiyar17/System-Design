package structuralDesignPattern;

// ================= SUBSYSTEM CLASSES =================

class PaymentService {

    public void makePayment(String accountId, double amount) {
        System.out.println("Payment successful: ₹" + amount);
    }
}

class SeatReservationService {

    public void reserveSeat(String movieId, String seatNumber) {
        System.out.println("Seat Reserved : " + seatNumber);
    }
}

class TicketService {

    public void generateTicket(String movieId, String seatNumber) {
        System.out.println("Ticket Generated");
    }
}

class NotificationService {

    public void sendNotification(String email) {
        System.out.println("Confirmation sent to " + email);
    }
}

// ================= FACADE =================

class MovieBookingFacade {

    private PaymentService paymentService;
    private SeatReservationService seatReservationService;
    private TicketService ticketService;
    private NotificationService notificationService;

    public MovieBookingFacade() {
        this.paymentService = new PaymentService();
        this.seatReservationService = new SeatReservationService();
        this.ticketService = new TicketService();
        this.notificationService = new NotificationService();
    }

    public void bookMovieTicket(String accountId,
                                String movieId,
                                String seatNumber,
                                String email,
                                double amount) {

        paymentService.makePayment(accountId, amount);
        seatReservationService.reserveSeat(movieId, seatNumber);
        ticketService.generateTicket(movieId, seatNumber);
        notificationService.sendNotification(email);

        System.out.println("Movie Ticket Booking Completed");
    }
}

// ================= CLIENT =================

public class FacadePattern {

    public static void main(String[] args) {

        MovieBookingFacade facade = new MovieBookingFacade();

        facade.bookMovieTicket(
                "USER123",
                "MOVIE101",
                "A10",
                "preet@gmail.com",
                500
        );
    }
}