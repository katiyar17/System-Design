public class HourlyPricingStrategy implements PricingStrategy{

    @Override
    public double calculateFee(Ticket ticket) {
         double totalCharge = ticket.exitTime - ticket.entryTime;
         return (long) totalCharge * (1.0);
    }
}
