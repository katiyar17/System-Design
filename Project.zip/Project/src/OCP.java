interface Transfer {
    void sendMoney();
}

class upi implements Transfer {

    @Override
    public void sendMoney() {
        System.out.println("l");
    }
}


public class OCP {
    public static void main(String[] args) {

        Transfer t1 = new upi();
        t1.sendMoney();

    }
}
