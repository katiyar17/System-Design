package behaviouralDesignPattern;

import java.util.ArrayList;
import java.util.List;

// ================= Observer =================
interface Subscriber {
    void update(String videoTitle);
}

// ================= Concrete Observer 1 =================
class EmailSubscriber implements Subscriber {

    private String email;

    public EmailSubscriber(String email) {
        this.email = email;
    }

    @Override
    public void update(String videoTitle) {
        System.out.println("Email sent to " + email +
                " : New video uploaded -> " + videoTitle);
    }
}

// ================= Concrete Observer 2 =================
class MobileSubscriber implements Subscriber {

    private String username;

    public MobileSubscriber(String username) {
        this.username = username;
    }

    @Override
    public void update(String videoTitle) {
        System.out.println("Push notification sent to " + username +
                " : New video uploaded -> " + videoTitle);
    }
}

// ================= Subject =================
interface Channel {
    void subscribe(Subscriber subscriber);

    void unsubscribe(Subscriber subscriber);

    void notifySubscribers(String videoTitle);
}

// ================= Concrete Subject =================
class YouTubeChannel implements Channel {

    private String channelName;
    private List<Subscriber> subscribers = new ArrayList<>();

    public YouTubeChannel(String channelName) {
        this.channelName = channelName;
    }

    @Override
    public void subscribe(Subscriber subscriber) {
        subscribers.add(subscriber);
    }

    @Override
    public void unsubscribe(Subscriber subscriber) {
        subscribers.remove(subscriber);
    }

    @Override
    public void notifySubscribers(String videoTitle) {

        for (Subscriber subscriber : subscribers) {
            subscriber.update(videoTitle);
        }
    }

    public void uploadVideo(String videoTitle) {

        System.out.println("\n" + channelName +
                " uploaded a new video : " + videoTitle);

        notifySubscribers(videoTitle);
    }
}

// ================= Client =================
public class ObserverDesignPattern {

    public static void main(String[] args) {

        // Subject
        YouTubeChannel tuf = new YouTubeChannel("takeUforward");

        // Observers
        Subscriber raj = new MobileSubscriber("Raj");
        Subscriber rahul = new EmailSubscriber("rahul@gmail.com");
        Subscriber preet = new MobileSubscriber("Preet");

        // Subscribe
        tuf.subscribe(raj);
        tuf.subscribe(rahul);
        tuf.subscribe(preet);

        // Upload Video
        tuf.uploadVideo("Observer Pattern Explained");

        System.out.println("\n----------------------");

        // Unsubscribe Rahul
        tuf.unsubscribe(rahul);

        // Upload Another Video
        tuf.uploadVideo("Strategy Pattern Explained");
    }
}