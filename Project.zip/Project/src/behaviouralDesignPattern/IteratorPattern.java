package behaviouralDesignPattern;
import java.util.ArrayList;
import java.util.List;

class Video {

    String title;

   public Video(String title) {
       this.title = title;
   }

    public String getTitle() {
        return title;
    }
}

interface PlaylistIterator {

    boolean hasNext();

    Video next();

}

interface Playlist {
    PlaylistIterator createIterator();
}

class YouTubePlaylist implements Playlist {

   private List<Video> videos = new ArrayList<>();

    public void addVideo(Video video) {
        videos.add(video);
    }

    @Override
    public PlaylistIterator createIterator() {
      return new YouTubePlaylistIterator(videos);
    }
}

class YouTubePlaylistIterator implements PlaylistIterator {

    private List<Video> videos;
    private int position;

    public YouTubePlaylistIterator(List<Video> videos) {
      this.videos = videos;
      this.position = 0;
    }

    @Override
    public boolean hasNext() {
          return position < videos.size();
    }

    @Override
    public Video next() {
           return videos.get(position++);
    }
}

public class IteratorPattern {
    public static void main(String[] args) {
        YouTubePlaylist youTubePlaylist = new YouTubePlaylist();
        youTubePlaylist.addVideo(new Video("Java"));
        youTubePlaylist.addVideo(new Video("Spring"));
        youTubePlaylist.addVideo(new Video("Kafka"));

        PlaylistIterator playlistIterator = youTubePlaylist.createIterator();

        while (playlistIterator.hasNext()) {
            Video video = playlistIterator.next();
            System.out.println(video.getTitle());

        }
    }
}
