interface Logistics {
    void send();
}

class Road implements Logistics {

    @Override
    public void send() {
        System.out.println("sending logistics on road");
    }
}

class Air implements Logistics {

    @Override
    public void send() {
        System.out.println("sending logistics by air");
    }
}



class LogisticFactory {
    public static Logistics getLogistics(String mode) {
        if (mode.equalsIgnoreCase("road")) {
            return new Road();
        } else if (mode.equalsIgnoreCase("air")) {
            return new Air();
        } else {
            throw new IllegalArgumentException("Invalid mode");
        }
    }
}

class LogisticsService {
    public void send(String mode) {

        Logistics logistics = LogisticFactory.getLogistics(mode);
        logistics.send();

    }
}

public class FactoryMethod {
    public static void main(String[] args) {

        LogisticsService service = new LogisticsService();

        service.send("road");
        service.send("air");
    }
}
