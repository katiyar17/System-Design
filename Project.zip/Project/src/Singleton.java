public class Singleton {
    // Volatile object declaration
    private static volatile Singleton instance;

    // Private constructor
    private Singleton() {}

    // Thread-safe method using double-checked locking
    public static Singleton getInstance() {
        if (instance == null) {
            synchronized (Singleton.class) { // Singleton.class = “use the class itself as a lock so only one thread enters”
                if (instance == null) {
                    instance = new Singleton();
                }
            }
        }
        return instance;
    }
}
