public interface PricingStrategy {
    double calculateFee(Ticket ticket);
}
