interface RecommendationStrategy {
    void recommend();
}

class TrendingRecommendation implements RecommendationStrategy {
    public void recommend() {

    }
 }

 class GenreRecommendation implements RecommendationStrategy{
     public void recommend() {

     }
 }

 class RecentRecommendation implements  RecommendationStrategy {
     public void recommend() {

     }
 }

 class Reccmmendation {
    private RecommendationStrategy recommendationStrategy;

     Reccmmendation(RecommendationStrategy recommendationStrategy) {
         this.recommendationStrategy = recommendationStrategy;
     }

     public void getRecommend() {
         recommendationStrategy.recommend();
     }
 }

 public class Main {
     public static void main(String[] args) {

         Reccmmendation reccmmendation = new Reccmmendation(new TrendingRecommendation());
         reccmmendation.getRecommend();

     }
}