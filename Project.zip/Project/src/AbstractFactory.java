interface PaymentGateway {
    void processPayment(double amount);
}

// ================= INDIA GATEWAYS =================

class RazorpayGateway implements PaymentGateway {
    public void processPayment(double amount) {
        System.out.println("Processing INR payment via Razorpay: " + amount);
    }
}

class PayUGateway implements PaymentGateway {
    public void processPayment(double amount) {
        System.out.println("Processing INR payment via PayU: " + amount);
    }
}

// ================= US GATEWAYS =================

class StripeGateway implements PaymentGateway {
    public void processPayment(double amount) {
        System.out.println("Processing USD payment via Stripe: " + amount);
    }
}

class PaypalGateway implements PaymentGateway {
    public void processPayment(double amount) {
        System.out.println("Processing USD payment via Paypal: " + amount);
    }
}

// ================= INVOICE =================

interface Invoice {
    void generateInvoice();
}

// India Invoice
class GSTInvoice implements Invoice {
    public void generateInvoice() {
        System.out.println("Generating GST Invoice for India");
    }
}

// US Invoice
class USInvoice implements Invoice {
    public void generateInvoice() {
        System.out.println("Generating US Invoice");
    }
}

// ================= ABSTRACT FACTORY =================

interface RegionFactory {

    PaymentGateway createPaymentGateway(String gatewayType);

    Invoice createInvoice();
}

// ================= INDIA FACTORY =================

class IndiaFactory implements RegionFactory {

    @Override
    public PaymentGateway createPaymentGateway(String gatewayType) {

        switch (gatewayType.toLowerCase()) {

            case "razorpay":
                return new RazorpayGateway();

            case "payu":
                return new PayUGateway();

            default:
                throw new IllegalArgumentException("Invalid India Gateway");
        }
    }

    @Override
    public Invoice createInvoice() {
        return new GSTInvoice();
    }
}

// ================= US FACTORY =================

class USFactory implements RegionFactory {

    @Override
    public PaymentGateway createPaymentGateway(String gatewayType) {

        switch (gatewayType.toLowerCase()) {

            case "stripe":
                return new StripeGateway();

            case "paypal":
                return new PaypalGateway();

            default:
                throw new IllegalArgumentException("Invalid US Gateway");
        }
    }

    @Override
    public Invoice createInvoice() {
        return new USInvoice();
    }
}

// ================= CHECKOUT SERVICE =================

class CheckoutService {

    private PaymentGateway paymentGateway;

    private Invoice invoice;

    public CheckoutService(RegionFactory factory, String gatewayType) {

        this.paymentGateway =
                factory.createPaymentGateway(gatewayType);

        this.invoice =
                factory.createInvoice();
    }

    public void checkOut(double amount) {

        paymentGateway.processPayment(amount);

        invoice.generateInvoice();
    }
}

// ================= MAIN =================

public class AbstractFactory {

    public static void main(String[] args) {

        // India Checkout
        CheckoutService indiaCheckout = new CheckoutService(new IndiaFactory(), "razorpay");

        indiaCheckout.checkOut(1500);

        System.out.println("----------------");

        // US Checkout
        CheckoutService usCheckout =
                new CheckoutService(
                        new USFactory(),
                        "stripe"
                );

        usCheckout.checkOut(200);
    }
}