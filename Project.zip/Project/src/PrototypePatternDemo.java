// ================= PROTOTYPE INTERFACE =================

interface EmailTemplate extends Cloneable {

    EmailTemplate cloneTemplate();

    void setContent(String content);

    void send(String to);
}

// ================= CONCRETE PROTOTYPE =================

class WelcomeEmail implements EmailTemplate {

    private String subject;

    private String content;

    // Constructor runs only once for original object
    public WelcomeEmail() {

        System.out.println("Loading heavy email template from database...");

        this.subject = "Welcome To TUF+";

        this.content = "Thanks for joining TUF+";
    }

    // Prototype cloning logic
    @Override
    public EmailTemplate cloneTemplate() {

        try {

            // Creates copy of current object
            return (WelcomeEmail) super.clone();

        } catch (CloneNotSupportedException e) {

            throw new RuntimeException("Clone failed");
        }
    }

    @Override
    public void setContent(String content) {

        this.content = content;
    }

    @Override
    public void send(String to) {

        System.out.println("--------------------------------");

        System.out.println("Sending Email To : " + to);

        System.out.println("Subject : " + subject);

        System.out.println("Content : " + content);
    }
}

// ================= PROTOTYPE REGISTRY =================

class EmailRegistry {

    // Storing original master template
    private static final WelcomeEmail welcomeTemplate =
            new WelcomeEmail();

    // Returning COPY not original
    public static EmailTemplate getWelcomeTemplate() {

        return welcomeTemplate.cloneTemplate();
    }
}

// ================= MAIN CLASS =================

public class PrototypePatternDemo {

    public static void main(String[] args) {

        // First user email
        EmailTemplate email1 =
                EmailRegistry.getWelcomeTemplate();

        email1.setContent(
                "Hi Alice, Welcome to Premium Membership!"
        );

        email1.send("alice@gmail.com");

        // Second user email
        EmailTemplate email2 =
                EmailRegistry.getWelcomeTemplate();

        email2.setContent(
                "Hi Bob, Thanks for joining TUF!"
        );

        email2.send("bob@gmail.com");

        // Third user email
        EmailTemplate email3 =
                EmailRegistry.getWelcomeTemplate();

        email3.setContent(
                "Hi Charlie, Let's start your learning journey!"
        );

        email3.send("charlie@gmail.com");
    }
}
/*
We’ll understand ONLY this code:

WelcomeEmail base = new WelcomeEmail();

WelcomeEmail copy = base.clone();

That’s the heart of Prototype.

Step 1
WelcomeEmail base = new WelcomeEmail();

Meaning:

👉 create ORIGINAL object.

Suppose internally:

subject = Welcome to TUF+
content = Thanks for joining

Now memory has ONE object.

Step 2
WelcomeEmail copy = base.clone();

Meaning:

👉 “Create DUPLICATE of base object.”

Now TWO objects exist.

Visualization
Original
base
subject = Welcome
content = Thanks
Clone
copy
subject = Welcome
content = Thanks

Initially same data.

BUT different objects.

Then this
copy.setContent("Hi Alice");

ONLY changes copy.

Original remains same.

Why useful?

Because original object acts like TEMPLATE.

Now actual confusing code
@Override
public WelcomeEmail clone() {
    try {
        return (WelcomeEmail) super.clone();
    } catch (CloneNotSupportedException e) {
        throw new RuntimeException("Clone failed", e);
    }
}

Now understand line-by-line.

This method
public WelcomeEmail clone()

means:

👉 “Give copy of current object.”

Most confusing part
super.clone()

This is Java’s built-in copy mechanism.

It automatically:

creates duplicate object
copies field values
Example

If original has:

subject = Welcome
content = Hello

then clone gets same values copied.

Why typecast?
(WelcomeEmail)

Because:

super.clone()

returns generic Object.

We convert back to WelcomeEmail.

Why implements Cloneable?
class WelcomeEmail implements Cloneable

Java safety rule.

Without this:

super.clone()

throws exception.

MOST IMPORTANT THING
This does NOT call constructor again

Very important.

Clone copies existing object directly.

Difference
Constructor
new WelcomeEmail()

runs full initialization again.

Clone
base.clone()

copies already-prepared object.

Faster.

Registry part simplified

This:

templates.put("welcome", new WelcomeEmail());

means:

👉 keep one original template stored.

Then
getTemplate("welcome")

returns:

clone()

NOT original object.

Why?

Because if user changes clone:

copy.setContent(...)

original template stays safe.

SUPER SIMPLE FLOW
App starts

Create one original template.

Welcome Email Template

Store safely.

User requests email

System:

copy template
change content
send
Another user requests email

Again:

copy original template
 */