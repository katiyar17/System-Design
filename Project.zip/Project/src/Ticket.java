class Ticket {
    String id;
    long entryTime;
    long exitTime;
}