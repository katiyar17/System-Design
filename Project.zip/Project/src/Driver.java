public class Driver {
    String driverId;
    boolean available;

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public String getDriverId() {
        return driverId;
    }
}
