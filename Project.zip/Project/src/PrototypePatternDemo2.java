interface EmailTemp extends Cloneable {

    EmailTemp cloneTemplate();
    void setContent(String content);
    void send(String to);

}

class WelcomeEmail2 implements EmailTemp {

    String content;
    String subject;

    // by default template creation while object creation
    public WelcomeEmail2() {
        this.content = "Welcome bro!";
        this.subject = "Thanks for joining TUF+";
    }

    @Override
    public EmailTemp cloneTemplate() {
        try {
            return (WelcomeEmail2) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("Clone failed", e);
        }
    }

    @Override
    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public void send(String to) {

    }
}

public class PrototypePatternDemo2 {
    public static void main(String[] args) {

    }
}
