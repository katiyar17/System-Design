package enums;
import dto.parkingSpot.Compact;
import dto.parkingSpot.Large;
import dto.parkingSpot.Mini;


public enum ParkingSpotEnums {

    COMPACT(Compact.class),
    MINI(Mini.class),
    LARGE(Large.class);

    private Class parkingSpot;

    /*Enum constants (COMPACT, MINI, LARGE) pass their class (Compact.class, Mini.class, etc.)
    into this constructor.
    That value gets stored in the field private Class parkingSpot*/

    ParkingSpotEnums(Class parkingSpot) {
        this.parkingSpot = parkingSpot;
    }
/* This simply returns the stored class object later when you need it*/
    public Class getParkingSpot() {
        return parkingSpot;
    }
}
