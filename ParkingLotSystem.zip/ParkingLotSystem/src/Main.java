import dto.ParkingLot;
import dto.ParkingTicket;
import dto.parkingSpot.ParkingSpot;
import dto.vehicle.Car;
import dto.vehicle.Vehicle;
import enums.ParkingSpotEnums;
import interfaces.ParkingSpotServices;
import interfaces.PaymentService;
import parkingStrategy.FarthestFirstParkingStrategy;
import services.ParkingServiceImpl;
import services.ParkingSpotServiceImpl;
import services.PaymentServiceImpl;

import java.lang.reflect.InvocationTargetException;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {

        ParkingLot parkingLot = ParkingLot.getInstance();
        ParkingSpotServices parkingSpotService = new ParkingSpotServiceImpl();

        ParkingSpot a1 = parkingSpotService.create(ParkingSpotEnums.COMPACT, 0);
        ParkingSpot a2 = parkingSpotService.create(ParkingSpotEnums.COMPACT, 0);

        ParkingSpot b1 = parkingSpotService.create(ParkingSpotEnums.LARGE, 0);
        ParkingSpot b2 = parkingSpotService.create(ParkingSpotEnums.LARGE, 0);

        ParkingSpot c1 = parkingSpotService.create(ParkingSpotEnums.MINI, 0);
        ParkingSpot c2 = parkingSpotService.create(ParkingSpotEnums.MINI, 0);

        Vehicle v1 = new Car();
        Vehicle v2 = new Car();
        Vehicle v3 = new Car();

        ParkingServiceImpl parkingLotService = new ParkingServiceImpl(new FarthestFirstParkingStrategy());
        PaymentService paymentService = new PaymentServiceImpl();
        ParkingTicket parkingTicket1 = parkingLotService.entry(v1);
        System.out.println("parking ticket 1: " + parkingTicket1);
        System.out.println("parking ticket 1 with vehicle id: " + parkingTicket1.getVehicle().getId());
        System.out.println(parkingTicket1.getVehicle().equals(v1) );





    }
}
