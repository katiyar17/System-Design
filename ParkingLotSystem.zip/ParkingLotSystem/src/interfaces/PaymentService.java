package interfaces;

public interface PaymentService {

    void acceptCash(int amount);

    void acceptCreditCard(String cardNo,int cvv,int amount);



}
