package interfaces;

import enums.ParkingSpotEnums;

public interface DisplayService {

  void update(ParkingSpotEnums parkingSpotEnums,int i);

}