package interfaces;

import dto.parkingSpot.ParkingSpot;
import enums.ParkingSpotEnums;

import java.lang.reflect.InvocationTargetException;

public interface ParkingSpotServices {

    ParkingSpot create(ParkingSpotEnums parkingSpotEnums, Integer floor) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException;

}
