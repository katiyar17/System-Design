package paymentMethods;

public class CreditCard extends PaymentMethod{

    private String cardNo;
    private int cvv;

    public CreditCard(String cardNo, int cvv) {
        this.cardNo = cardNo;
        this.cvv = cvv;
    }

    @Override
    public boolean initiatePayment(int amount) {
        return false;
    }
}
