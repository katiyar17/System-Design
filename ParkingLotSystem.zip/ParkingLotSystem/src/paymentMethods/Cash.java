package paymentMethods;

public class Cash extends PaymentMethod{

    @Override
    public boolean initiatePayment(int amount) {
        System.out.println("Making payment for Rs" + " " + amount);
        return true;
    }
}
