package parkingStrategy;

import dto.exceptions.SpotNotFoundException;
import dto.parkingSpot.ParkingSpot;
import enums.ParkingSpotEnums;

public interface Strategy {

    ParkingSpot findParkingSpot(ParkingSpotEnums parkingSpotEnums) throws SpotNotFoundException;
}
