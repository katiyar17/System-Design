package parkingStrategy;

import dto.ParkingLot;
import dto.exceptions.SpotNotFoundException;
import dto.parkingSpot.ParkingSpot;
import enums.ParkingSpotEnums;

import java.util.List;

public class NearestFirstParkingStrategy implements Strategy {

    @Override
    public ParkingSpot findParkingSpot(ParkingSpotEnums parkingSpotEnums) throws SpotNotFoundException {

        List<ParkingSpot> parkingSpots = ParkingLot.getInstance().getFreeParkingSpots().get(parkingSpotEnums);
        if (parkingSpots.size() == 0) {
            throw new SpotNotFoundException("Spot not found!");
        }
     return parkingSpots.get(0);
    }

}
