package parkingStrategy;

import dto.ParkingLot;
import dto.exceptions.SpotNotFoundException;
import dto.parkingSpot.ParkingSpot;
import enums.ParkingSpotEnums;

import java.util.List;

public class FarthestFirstParkingStrategy implements Strategy {

    @Override
    public ParkingSpot findParkingSpot(ParkingSpotEnums parkingSpotEnums) throws SpotNotFoundException {
        List<ParkingSpot> parkingSpots = ParkingLot.getInstance().getFreeParkingSpots().get(parkingSpotEnums);
        if (parkingSpots.size() == 0) {
            throw new SpotNotFoundException("Spot not found  for farthest!");
        }
        return parkingSpots.get(parkingSpots.size()-1 );
    }
}
