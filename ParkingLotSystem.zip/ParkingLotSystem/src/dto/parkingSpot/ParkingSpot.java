package dto.parkingSpot;

import java.util.concurrent.atomic.AtomicInteger;

public abstract class ParkingSpot {

    private static final AtomicInteger x = new AtomicInteger(0);
    private int id;
    private boolean isFree;
    protected int amount;
    private int floor;

    public ParkingSpot(){}

    public ParkingSpot(int floor, int amount) {
        this.floor = floor;
        this.amount = amount;
        isFree = true;
        id = x.incrementAndGet();
    }

    public int getId() {
        return id;
    }

    public boolean isFree() {
        return isFree;
    }

    public int getAmount() {
        return amount;
    }

    public int getFloor() {
        return floor;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setFloor(int floor) {
        this.floor = floor;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public void setFree(boolean free) {
        isFree = free;
    }

    public abstract int cost(int parkingHours);
}
