package dto;
import enums.ParkingSpotEnums;
import java.util.HashMap;
import java.util.Map;

public class DisplayBoard {

    private static DisplayBoard displayBoard= null;
    private Map<ParkingSpotEnums, Integer> freeParkingSpot;

    /*
    Map<ParkingSpotEnums, Integer> freeParkingSpot; map meaning
    {
   COMPACT -> 10,
   MINI -> 5,
   LARGE -> 2
}
   */

    private DisplayBoard() {
        this.freeParkingSpot = new HashMap<>();
    }

    public static DisplayBoard getInstance() {
        if (displayBoard == null) {
            displayBoard = new DisplayBoard();
        }
        return displayBoard;
    }

    public Map<ParkingSpotEnums, Integer> getFreeParkingSpot() {
        return freeParkingSpot;
    }



}
