package dto.accounts;

import dto.ParkingLot;

public class Admin extends Accounts {

    private ParkingLot parkingLot = ParkingLot.getParkingLot();


}
