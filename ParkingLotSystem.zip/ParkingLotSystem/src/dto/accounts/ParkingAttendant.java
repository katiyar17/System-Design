package dto.accounts;

public class ParkingAttendant extends Accounts{



}
