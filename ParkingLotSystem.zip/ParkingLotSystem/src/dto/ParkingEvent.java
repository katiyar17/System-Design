package dto;

import enums.ParkingEventType;
import enums.ParkingSpotEnums;

public class ParkingEvent {

    private ParkingEventType eventType;

    public ParkingEvent(ParkingEventType eventType, ParkingSpotEnums parkingSpotEnums) {
        this.eventType = eventType;
        this.parkingSpotEnums = parkingSpotEnums;
    }

    public ParkingEventType getEventType() {
        return eventType;
    }

    public void setEventType(ParkingEventType eventType) {
        this.eventType = eventType;
    }

    public ParkingSpotEnums getParkingSpotEnums() {
        return parkingSpotEnums;
    }

    public void setParkingSpotEnums(ParkingSpotEnums parkingSpotEnums) {
        this.parkingSpotEnums = parkingSpotEnums;
    }

    private ParkingSpotEnums parkingSpotEnums;


}
