package dto;

public class EntrancePannel {

    private String name;

    public EntrancePannel(String name) {
        this.name = name;
    }
}
