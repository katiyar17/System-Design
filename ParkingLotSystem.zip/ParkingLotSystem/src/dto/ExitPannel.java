package dto;

public class ExitPannel {

    private String name;

    public ExitPannel(String name) {
        this.name = name;
    }
}
