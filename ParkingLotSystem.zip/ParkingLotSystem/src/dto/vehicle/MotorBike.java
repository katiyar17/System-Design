package dto.vehicle;

import enums.ParkingSpotEnums;

public class MotorBike extends Vehicle {

    public MotorBike() {
        super(ParkingSpotEnums.MINI);
    }
}
