package dto.vehicle;

import enums.ParkingSpotEnums;

import javax.swing.plaf.PanelUI;

public class Car extends Vehicle {

    public Car() {
        super(ParkingSpotEnums.COMPACT);
    }
}
