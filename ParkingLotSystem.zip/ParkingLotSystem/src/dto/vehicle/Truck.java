package dto.vehicle;

import enums.ParkingSpotEnums;

public class Truck extends Vehicle {

    public Truck() {
        super(ParkingSpotEnums.LARGE);
    }
}
