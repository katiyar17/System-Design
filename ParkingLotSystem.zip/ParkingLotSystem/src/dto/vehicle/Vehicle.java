package dto.vehicle;
import enums.ParkingSpotEnums;
import java.util.concurrent.atomic.AtomicInteger;

public class Vehicle {

    private static final AtomicInteger x = new AtomicInteger(0);
    private int id;
    private ParkingSpotEnums parkingSpotEnums;

    public Vehicle(ParkingSpotEnums parkingSpotEnums) {
        this.parkingSpotEnums = parkingSpotEnums;
        id = x.incrementAndGet();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ParkingSpotEnums getParkingSpotEnums() {
        return parkingSpotEnums;
    }

    public void setParkingSpotEnums(ParkingSpotEnums parkingSpotEnums) {
        this.parkingSpotEnums = parkingSpotEnums;
    }

}
