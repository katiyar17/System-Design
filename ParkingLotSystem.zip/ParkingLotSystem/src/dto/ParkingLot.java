package dto;
import dto.parkingSpot.ParkingSpot;
import enums.ParkingSpotEnums;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ParkingLot {

    private static ParkingLot parkingLot = null; // holds the only object

    private String name;
    private List<EntrancePannel> entrances;
    private List<ExitPannel> exits;
    private DisplayBoard displayBoard;
    private Map<ParkingSpotEnums,List<ParkingSpot>> freeParkingSpots;
    private Map<ParkingSpotEnums,List<ParkingSpot>> occupiedParkingSpots;

    private ParkingLot(String name) {
        this.name = name;
        this.entrances = new ArrayList<>();
        this.exits = new ArrayList<>();
        this.displayBoard = DisplayBoard.getInstance();
        this.freeParkingSpots = new HashMap<>();
        this.occupiedParkingSpots = new HashMap<>();

        // ✅ Initialize empty lists for each enum type
        for (ParkingSpotEnums type : ParkingSpotEnums.values()) {
            freeParkingSpots.put(type, new ArrayList<>());
            occupiedParkingSpots.put(type, new ArrayList<>());
        }

        // ✅ Also initialize the display board counts
        for (ParkingSpotEnums type : ParkingSpotEnums.values()) {
            displayBoard.getFreeParkingSpot().put(type, 0);
        }
    }


    public static ParkingLot getInstance() {
        if (parkingLot == null) {
            parkingLot = new ParkingLot("abc"); // create it only once
        }
        return parkingLot; // always return same object
    }


    public static ParkingLot getParkingLot() {
        return parkingLot;
    }

    public static void setParkingLot(ParkingLot parkingLot) {
        ParkingLot.parkingLot = parkingLot;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<EntrancePannel> getEntrances() {
        return entrances;
    }

    public void setEntrances(List<EntrancePannel> entrances) {
        this.entrances = entrances;
    }

    public List<ExitPannel> getExits() {
        return exits;
    }

    public void setExits(List<ExitPannel> exits) {
        this.exits = exits;
    }

    public DisplayBoard getDisplayBoard() {
        return displayBoard;
    }

    public void setDisplayBoard(DisplayBoard displayBoard) {
        this.displayBoard = displayBoard;
    }

    public Map<ParkingSpotEnums, List<ParkingSpot>> getFreeParkingSpots() {
        return freeParkingSpots;
    }

    public void setFreeParkingSpots(Map<ParkingSpotEnums, List<ParkingSpot>> freeParkingSpots) {
        this.freeParkingSpots = freeParkingSpots;
    }

    public Map<ParkingSpotEnums, List<ParkingSpot>> getOccupiedParkingSpots() {
        return occupiedParkingSpots;
    }

    public void setOccupiedParkingSpots(Map<ParkingSpotEnums, List<ParkingSpot>> occupiedParkingSpots) {
        this.occupiedParkingSpots = occupiedParkingSpots;
    }
}
