package services;

import dto.DisplayBoard;
import dto.ParkingEvent;
import enums.ParkingEventType;
import enums.ParkingSpotEnums;
import interfaces.DisplayService;
import interfaces.Observer;

public class DisplayServiceImpl implements DisplayService , Observer {
    @Override
    public void update(ParkingEvent event) {
        int currentCount = DisplayBoard.getInstance().getFreeParkingSpot().get(event.getParkingSpotEnums());
        int change = 0;
        if (event.getEventType().equals(ParkingEventType.ENTRY)) {
            change =- 1;
        } else {
            change = 1;
        }
       int newCount = currentCount + change;
        DisplayBoard.getInstance().getFreeParkingSpot().replace(event.getParkingSpotEnums(),newCount);
        return;
    }

    public void update(ParkingSpotEnums parkingSpotEnums, int change) {
        Integer currentCount = DisplayBoard.getInstance().getFreeParkingSpot().get(parkingSpotEnums);
        if (currentCount == null) {
            currentCount = 0;
        }
        int newCount = currentCount+change;
        DisplayBoard.getInstance().getFreeParkingSpot().replace(parkingSpotEnums,newCount);

    }
}
