package services;

import dto.ParkingEvent;
import dto.ParkingLot;
import dto.ParkingTicket;
import dto.exceptions.InvalidTicketException;
import dto.parkingSpot.ParkingSpot;
import dto.parkingSpot.spotDecorator.Wash;
import dto.vehicle.Vehicle;
import enums.ParkingEventType;
import enums.ParkingSpotEnums;
import interfaces.DisplayService;
import interfaces.Observer;
import interfaces.ParkingService;
import parkingStrategy.Strategy;

import java.util.ArrayList;
import java.util.List;

public class ParkingServiceImpl  implements ParkingService {

    Strategy parkingStrategy;
    ParkingLot parkingLot;
    DisplayService displayService;
    List<Observer> observers;

    public ParkingServiceImpl(Strategy parkingStrategy) {
        this.parkingStrategy = parkingStrategy;
        this.parkingLot = ParkingLot.getInstance();
        displayService = new DisplayServiceImpl();
        observers = new ArrayList<>();
    }

    @Override
    public ParkingTicket entry(Vehicle vehicle)   {
        ParkingSpotEnums parkingSpotEnums = vehicle.getParkingSpotEnums();

        List<ParkingSpot> freeParkingSpot = parkingLot.getFreeParkingSpots().get(parkingSpotEnums);
        List<ParkingSpot> occupiedParkingSpot = parkingLot.getOccupiedParkingSpots().get(parkingSpotEnums);

        try {
            ParkingSpot parkingSpot = parkingStrategy.findParkingSpot(parkingSpotEnums);
            if(parkingSpot.isFree()) {
                 synchronized (parkingSpot) {
                     if (parkingSpot.isFree()) {
                         parkingSpot.setFree(false);
                         freeParkingSpot.remove(parkingSpot);
                         occupiedParkingSpot.add(parkingSpot);
                         ParkingTicket parkingTicket = new ParkingTicket(vehicle,parkingSpot);

                 ParkingEvent parkingEvent = new ParkingEvent(ParkingEventType.ENTRY, parkingSpotEnums);
                 notifyAllObservers(parkingEvent);
                         return parkingTicket;
                     }
                     entry(vehicle);
                 }
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    private void addObserver(Observer observer) {
         observers.add(observer);
    }

    public void notifyAllObservers(ParkingEvent parkingEvent) {
        for(Observer observer: observers) {
            observer.update(parkingEvent);
        }
    }


    private void addParkingSpotOnRightPlace(List<ParkingSpot> parkingSpots, ParkingSpot parkingSpot){
        parkingSpots.add(parkingSpot);
    }

    public void addWash(ParkingTicket parkingTicket) {
      parkingTicket.setParkingSpot(new Wash(parkingTicket.getParkingSpot()));
      return;
    }

    @Override
    public int exit(ParkingTicket parkingTicket, Vehicle vehicle) throws InvalidTicketException {

        if (parkingTicket.getParkingSpot().equals(vehicle)) {
          // find the amount person has to pay after parking when about to exit

            ParkingSpot parkingSpot = parkingTicket.getParkingSpot();
            // here amount not in ticket because amount only calculated based on how much time vehicle present on spot
            int amount = parkingSpot.getAmount();
            parkingSpot.setFree(true);
            parkingLot.getOccupiedParkingSpots().get(vehicle.getParkingSpotEnums()).remove(parkingSpot);
            addParkingSpotOnRightPlace(parkingLot.getFreeParkingSpots().get(vehicle.getParkingSpotEnums()), parkingSpot);

  ParkingEvent parkingEvent = new ParkingEvent(ParkingEventType.EXIT, vehicle.getParkingSpotEnums());
  notifyAllObservers(parkingEvent);
  return amount;

        } else {
            throw new InvalidTicketException("Its an invalid ticket!");
        }

    }
}
