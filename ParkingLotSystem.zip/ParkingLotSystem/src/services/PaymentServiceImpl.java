package services;

import interfaces.PaymentService;
import paymentMethods.Cash;
import paymentMethods.CreditCard;
import paymentMethods.PaymentMethod;

public class PaymentServiceImpl implements PaymentService {
    @Override
    public void acceptCash(int amount) {
        PaymentMethod cash  = new Cash();
        cash.initiatePayment(amount);
    }

    @Override
    public void acceptCreditCard(String cardNo, int cvv, int amount) {
        PaymentMethod card = new CreditCard(cardNo, cvv);
        card.initiatePayment(amount);
    }
}
