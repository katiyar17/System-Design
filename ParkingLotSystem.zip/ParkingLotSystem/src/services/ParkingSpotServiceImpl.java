package services;

import dto.ParkingLot;
import dto.parkingSpot.ParkingSpot;
import enums.ParkingSpotEnums;
import interfaces.DisplayService;
import interfaces.ParkingSpotServices;

import java.lang.reflect.InvocationTargetException;

public class ParkingSpotServiceImpl implements ParkingSpotServices {

        DisplayService displayService = new DisplayServiceImpl();

    @Override
    public ParkingSpot create(ParkingSpotEnums parkingSpotEnums, Integer floor) {
        try {
            ParkingSpot parkingSpot = (ParkingSpot) parkingSpotEnums.getParkingSpot().getConstructor(Integer.class).newInstance(floor);
            ParkingLot.getInstance().getFreeParkingSpots().get(parkingSpotEnums).add(parkingSpot);
            displayService.update(parkingSpotEnums, 1);
            return parkingSpot;

        } catch (InstantiationException e) {
            throw new RuntimeException(e);

        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);

        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);

        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }


}
