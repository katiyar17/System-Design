package customerissueresolution.model;

public class Issue {

    private String issueId;
    private String transactionId;
    private IssueType issueType;
    private String subject;
    private String description;
    private String customerEmail;
    private IssueStatus status;
    private String resolution;
    private String assignedAgentId;

    public Issue(String issueId, String transactionId, IssueType issueType,  String subject, String description, String customerEmail) {
        this.issueId = issueId;
        this.issueType = issueType;
        this.subject = subject;
        this.transactionId = transactionId;
        this.description = description;
        this.status = IssueStatus.OPEN;
        this.customerEmail = customerEmail;
    }

    public String getIssueId() {
        return issueId;
    }

    public IssueType getIssueType() {
        return issueType;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public IssueStatus getStatus() {
        return status;
    }

    public String getAssignedAgentId() {
        return assignedAgentId;
    }

    public void setIssueId(String issueId) {
        this.issueId = issueId;
    }

    public void setStatus(IssueStatus status) {
        this.status = status;
    }

    public void setAssignedAgentId(String assignedAgentId) {
        this.assignedAgentId = assignedAgentId;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    @Override
    public String toString() {
        return issueId + "[" + transactionId + ", " + issueType + ", " + subject + ", " + description + ", " +
                customerEmail + ", " + status + "]";
    }
}
