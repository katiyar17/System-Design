package customerissueresolution.model;

import java.util.ArrayList;
import java.util.List;

public class Agent {

    private String email;
    private String name;
    private List<IssueType> expertise;
    private List<String> workHistory;
    private boolean busy;

    public Agent(String email, String name, List<IssueType> expertise) {
        this.name = name;
        this.email = email;
        this.workHistory = new ArrayList<>();
        this.expertise = expertise;
        this.busy = false;
    }

    public boolean isBusy() {
        return busy;
    }

    public String getEmail() {
        return email;
    }

    public List<IssueType> getExpertise() {
        return expertise;
    }

    public List<String> getWorkHistory() {
        return workHistory;
    }

    public void assignIssue(String issueId) {
        workHistory.add(issueId);
        busy = true;
    }

    public String getName() {
        return name;
    }

    public void freeAgent() {
        busy = false;
    }
}
