package customerissueresolution.model;

public enum IssueStatus {
    OPEN,
    IN_PROGRESS,
    RESOLVED
}
