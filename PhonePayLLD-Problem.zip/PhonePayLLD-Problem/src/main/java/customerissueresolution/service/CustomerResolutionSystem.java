package customerissueresolution.service;
import customerissueresolution.model.*;
import java.util.*;


public class CustomerResolutionSystem {

    private Map<String, Agent> agents = new HashMap<>();
    private Queue<String> waitlist = new LinkedList<>();
    private Map<String, Issue> issues = new HashMap<>();
    private int issueCounter = 1;

    public void createIssue(String transactionId, IssueType type, String subject, String description,
                            String email) {

        String issueId = "I" + issueCounter++;
        Issue issue = new Issue(issueId, transactionId, type, subject, description, email);
        issues.put(issueId,issue);
        System.out.println(">>> Isuue" + issueId + "created against transaction \"" + transactionId + "\"");
    }

    public void addAgent(String email, String name, List<IssueType> expertise) {
        agents.put(email,new Agent(email,name,expertise));
        System.out.println(">>> Agent " + name + " created");
    }

    public void asssignIssue(String issueId) {
        Issue issue = issues.get(issueId);
        if(issue == null) {
            return;
        }

        for(Agent agent : agents.values()) {
            if(!agent.isBusy() && agent.getExpertise().contains(issue.getIssueType())) {
                agent.assignIssue(issueId);
                issue.setAssignedAgentId(agent.getEmail());
                System.out.println(">>> Issue " + issueId + " assigned to agent " + agent.getName());
                return;
            }
        }
        waitlist.add(issueId);
        System.out.println(">>> Issue " + issueId + " added to waitlist");
    }

    public void getIssue(Map<String,String> filter) {
        for(Issue issue : issues.values()) {
            if(filter.containsKey("email") && issue.getCustomerEmail().equals(filter.get("email"))) {
                System.out.println(issue);
            } else if(filter.containsKey("type") && issue.getIssueType().toString().equalsIgnoreCase(filter.get("type"))) {
                System.out.println(issue);
            }
        }
    }

    public void updateIssue(String issueId, IssueStatus status, String resolution) {
        Issue issue = issues.get(issueId);
        if (issue != null) {
            issue.setStatus(status);
            issue.setResolution(resolution);

            if (status == IssueStatus.RESOLVED) {
                if (issue.getAssignedAgentId() != null) {
                    Agent agent = agents.get(issue.getAssignedAgentId());
                    if (agent != null) {
                        agent.freeAgent();
                        assignFromWaitlist(agent);
                        System.out.println(">>> Issue " + issueId + " updated to " + status);
                    }
                } else {
                    System.out.println(">>> Issue " + issueId + " resolved but was never assigned to any agent");
                }
            }
        }
    }

    public void viewAgentsWorkHistory() {
        for(Agent agent : agents.values()) {
            System.out.println(agent.getName() + " -> " + agent.getWorkHistory());
        }
    }

    private void assignFromWaitlist(Agent agent) {
        Iterator<String> it = waitlist.iterator();
        while (it.hasNext()) {
            String nextIssueId = it.next();
            Issue nextIssue = issues.get(nextIssueId);
            if (agent.getExpertise().contains(nextIssue.getIssueType()) && nextIssue.getStatus() == IssueStatus.OPEN) {
                agent.assignIssue(nextIssueId);
                nextIssue.setAssignedAgentId(agent.getEmail());
                System.out.println(">>> Issue " + nextIssueId + " assigned to agent " + agent.getName() + " from waitlist");
                it.remove();
                break;
            }
        }
    }
}
