package org.example;

import customerissueresolution.model.Issue;
import customerissueresolution.model.IssueStatus;
import customerissueresolution.model.IssueType;
import customerissueresolution.service.CustomerResolutionSystem;

import java.util.Arrays;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        CustomerResolutionSystem system = new CustomerResolutionSystem();
        system.createIssue("T1", IssueType.PAYMENT_RELATED, "Payment Failed", "My payment failed but money is debited",
"testUser1@test.com");

        system.createIssue("T2", IssueType.MUTUAL_FUND_RELATED, "Purchase Failed", "Unable to purchase Mutual Fund", "testUser2@test.com");


        system.createIssue("T3", IssueType.PAYMENT_RELATED, "Payment Failed", "My payment failed but money is debited",
                "testUser3@test.com");

        system.addAgent("agent1@test.com", "Agent 1", Arrays.asList(IssueType.PAYMENT_RELATED, IssueType.GOLD_RELATED));
        system.addAgent("agent2@test.com", "Agent 2", Arrays.asList(IssueType.MUTUAL_FUND_RELATED));

        system.asssignIssue("I1");
        system.asssignIssue("I2");
        system.asssignIssue("I3");

        system.getIssue(java.util.Map.of("email", "testUser2@test.com"));
        system.getIssue(java.util.Map.of("type", "PAYMENT_RELATED"));

        system.updateIssue("I1", IssueStatus.RESOLVED, "Done");
        system.updateIssue("I3", IssueStatus.RESOLVED, "Done");


        system.viewAgentsWorkHistory();


    }
}