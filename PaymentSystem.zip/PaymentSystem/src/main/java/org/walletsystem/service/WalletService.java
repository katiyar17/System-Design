package org.walletsystem.service;
import org.walletsystem.enums.TransactionType;
import org.walletsystem.model.Transaction;
import org.walletsystem.model.Wallet;
import org.walletsystem.repository.TransactionRepository;
import org.walletsystem.repository.WalletRepository;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class WalletService {

    private final WalletRepository walletRepository;
    private final IdempotencyService idempotencyService;
    private final TransactionRepository transactionRepository;
    private final Map<String, Object> walletLocks = new ConcurrentHashMap<>();
    private final LedgerService ledgerService;
    private final TransactionManager transactionManager;

    public WalletService(WalletRepository walletRepository, IdempotencyService idempotencyService, TransactionRepository transactionRepository, LedgerService ledgerService, TransactionManager transactionManager) {
        this.walletRepository = walletRepository;
        this.idempotencyService = idempotencyService;
        this.transactionRepository = transactionRepository;
        this.ledgerService = ledgerService;
        this.transactionManager = transactionManager;
    }

    public String createWallet(String userId) {
        Wallet wallet = new Wallet(userId);
        walletRepository.save(wallet);
        return wallet.getWalletId();
    }

    private Object getLockForWallet(String walletId) {
        return walletLocks.computeIfAbsent(walletId, id -> new Object());
    }



    public String transfer(String senderWalletId, String receiverWalletId, BigDecimal amount,
                         String idempotencyKey) {

        String transferRefId = UUID.randomUUID().toString();

        String existing = idempotencyService.putIfAbsent(idempotencyKey, transferRefId);

        if (existing != null) {
            return existing;
        }

        // check if both wallets are not same
        if (senderWalletId.equals(receiverWalletId)) {
            throw new IllegalStateException("transfer to same wallet not allowed!");
        }

        // load wallet
        Wallet senderWallet = walletRepository.findById(senderWalletId).orElseThrow(() ->
             new IllegalStateException("Sender Wallet Not Found!"));

        Wallet receiverWallet = walletRepository.findById(receiverWalletId).orElseThrow(() ->
                new IllegalStateException("Receiver Wallet Not Found!"));

        Wallet firstWallet;
        Wallet secondWallet;

        if (senderWallet.getWalletId().compareTo(receiverWallet.getWalletId()) < 0) {

            firstWallet = senderWallet;
            secondWallet = receiverWallet;
        } else {

            firstWallet = receiverWallet;
            secondWallet = senderWallet;
        }

        Object lock1 = getLockForWallet(firstWallet.getWalletId());
        Object lock2 = getLockForWallet(secondWallet.getWalletId());

         synchronized (lock1) {
            synchronized (lock2) {

                transactionManager.executeTransfer(senderWallet, receiverWallet, amount, transferRefId);

            }
         }

         return transferRefId;
    }
    
    public Wallet getWallet(String walletId) {
        Wallet wallet = walletRepository.findById(walletId)
                .orElseThrow(() -> new IllegalStateException("Wallet not found"));
        return wallet;
    }



    public List<Transaction> getWalletTransactions(String walletId) {
        return transactionRepository.findByWalletId(walletId);
    }

    public Transaction getTransferTransaction(String transferRefId) {
        List<Transaction> transactions = transactionRepository.findByTransferRefId(transferRefId);
        if (transactions.isEmpty()) {
            throw new IllegalStateException("Transaction not found");
        }
        return transactions.get(0);
    }

    public void deposit(String walletId, BigDecimal amount) {

        Object lock = getLockForWallet(walletId);
        synchronized (lock) {

            Wallet wallet = getWallet(walletId);

            Transaction txn = new Transaction(walletId, UUID.randomUUID().toString(), amount, TransactionType.CREDIT);

            transactionRepository.save(txn);
            txn.markProcessing();
            wallet.credit(amount);

            ledgerService.recordEntry(walletId, txn.getTransactionId(), amount,
                    TransactionType.CREDIT);

            txn.markSuccess();
        }
    }

    public void reverseTransaction(String transferRefId) {

        List<Transaction> transactions =
                transactionRepository.findByTransferRefId(transferRefId);

        if (transactions.size() != 2) {
            throw new IllegalStateException("Invalid transfer reference");
        }

        Transaction debitTxn = null;
        Transaction creditTxn = null;

        for (Transaction txn : transactions) {
            if (txn.getTransactionType() == TransactionType.DEBIT) {
                debitTxn = txn;
            }
            if (txn.getTransactionType() == TransactionType.CREDIT) {
                creditTxn = txn;
            }
        }



        String senderWalletId = debitTxn.getWalletId();
        String receiverWalletId = creditTxn.getWalletId();
        BigDecimal amount = debitTxn.getAmount();


        Wallet senderWallet = walletRepository.findById(senderWalletId)
                .orElseThrow(() -> new IllegalStateException("sender wallet not found"));

        Wallet receiverWallet = walletRepository.findById(receiverWalletId)
                .orElseThrow(() -> new IllegalStateException("receiver wallet not found"));

        // reverse transfer (swap wallets)

        synchronized (senderWallet) {
            synchronized (receiverWallet) {
                transactionManager.executeTransfer(
                        receiverWallet,
                        senderWallet,
                        amount,
                        UUID.randomUUID().toString()
                );
            }
        }
    }
}
