package org.walletsystem.service;

import org.walletsystem.enums.TransactionType;
import org.walletsystem.model.LedgerEntry;
import org.walletsystem.repository.LedgerRepository;
import org.walletsystem.repository.TransactionRepository;
import org.walletsystem.repository.WalletRepository;

import java.math.BigDecimal;

public class LedgerService {

    private final LedgerRepository ledgerRepository;
    public LedgerService(LedgerRepository ledgerRepository) {
        this.ledgerRepository = ledgerRepository;
    }

    public void recordEntry(String walletId,
                            String transactionId,
                            BigDecimal amount,
                            TransactionType type) {

        LedgerEntry ledgerEntry = new LedgerEntry(walletId, transactionId, amount, type);
        ledgerRepository.save(ledgerEntry);

    }

}
