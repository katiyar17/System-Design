package org.walletsystem.service;
import org.walletsystem.enums.TransactionType;
import org.walletsystem.enums.TransferType;
import org.walletsystem.strategy.TransferStrategy;
import org.walletsystem.factory.TransferStrategyFactory;
import org.walletsystem.model.Transaction;
import org.walletsystem.model.Wallet;
import org.walletsystem.repository.TransactionRepository;
import org.walletsystem.repository.WalletRepository;
import java.math.BigDecimal;

public class TransactionManager {

    private final WalletRepository walletRepository;
    private final TransferStrategyFactory transferStrategyFactory;
    private final TransactionRepository transactionRepository;
    private final LedgerService ledgerService;

    public TransactionManager(WalletRepository walletRepository, TransactionRepository transactionRepository, LedgerService ledgerService,
                              TransferStrategyFactory transferStrategyFactory) {
        this.walletRepository = walletRepository;
        this.transferStrategyFactory = transferStrategyFactory;
        this.transactionRepository = transactionRepository;
        this.ledgerService = ledgerService;
    }

    public void executeTransfer(Wallet senderWallet, Wallet receiverWallet, BigDecimal amount, String transferRefId) {


        TransferStrategy strategy = transferStrategyFactory.getStrategy(TransferType.WALLET_TO_WALLET);
        strategy.transfer(senderWallet, receiverWallet, amount, transferRefId);

    }
}
