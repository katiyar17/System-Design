package org.walletsystem.service;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class IdempotencyService {

    private final Map<String, String> idempotencyStore = new ConcurrentHashMap<>();

    public boolean exits(String idempotencyKey) {
        return idempotencyStore.containsKey(idempotencyKey);
    }

    public String putIfAbsent(String key, String transferRefId) {
        return idempotencyStore.putIfAbsent(key, transferRefId);
    }

}
