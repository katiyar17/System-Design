package org.walletsystem.model;
import java.util.UUID;

public class User {

    private final String userId;
    private final String userName;
    private final String contactNo;

    public User(String userName, String contactNo) {
        this.userId = UUID.randomUUID().toString();
        this.userName = userName;
        this.contactNo = contactNo;
    }

    @Override
    public boolean equals(Object o) {
        if(this == o) return true;
        if(!(o instanceof User user)) return false;
        return userId.equals(user.userId);
    }

    public String getUserId() {
        return userId;
    }

    public String getUserName() {
        return userName;
    }

    public String getContactNo() {
        return contactNo;
    }
}
