package org.walletsystem.model;
import org.walletsystem.enums.TransactionType;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

public class LedgerEntry {

    private final String entryId;
    private final String walletId;
    private final String transactionId;
    private final BigDecimal amount;
    private final TransactionType type;
    private final LocalDateTime createdAt;

    public LedgerEntry(String walletId,
                       String transactionId,
                       BigDecimal amount,
                       TransactionType type) {

        this.entryId = UUID.randomUUID().toString();
        this.walletId = walletId;
        this.transactionId = transactionId;
        this.amount = amount;
        this.type = type;
        this.createdAt = LocalDateTime.now();
    }

    public String getWalletId() {
        return walletId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public TransactionType getType() {
        return type;
    }

    @Override
    public String toString() {
        return "LedgerEntry{" +
                "walletId='" + walletId + '\'' +
                ", transactionId='" + transactionId + '\'' +
                ", amount=" + amount +
                ", type=" + type +
                '}';
    }

}
