package org.walletsystem.model.state;

import org.walletsystem.model.Wallet;

import java.math.BigDecimal;

public class ClosedState implements WalletState {

    @Override
    public void credit(Wallet wallet, BigDecimal amount) {
        throw new IllegalStateException("Wallet is closed");
    }

    @Override
    public void debit(Wallet wallet, BigDecimal amount) {
        throw new IllegalStateException("Wallet is closed");
    }

    @Override
    public void freeze(Wallet wallet) {
        throw new IllegalStateException("Wallet is closed");
    }

    @Override
    public void activate(Wallet wallet) {
        throw new IllegalStateException("Wallet is closed");
    }

    @Override
    public void close(Wallet wallet) {

    }
}
