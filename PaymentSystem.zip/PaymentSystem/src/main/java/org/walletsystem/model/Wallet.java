package org.walletsystem.model;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;
import org.walletsystem.model.state.WalletState;
import org.walletsystem.model.state.ActiveState;

public class Wallet {

    private final String walletId;
    private final String userId;
    private final LocalDate createdAt;
    private WalletState state;
    private BigDecimal balance;
    private final Object lock = new Object();

    public Wallet(String userId) {
        if (userId == null) {
            throw new IllegalArgumentException("UserId cannot be null");
        }
        this.walletId = UUID.randomUUID().toString();
        this.userId = userId;
        this.createdAt = LocalDate.now();
        this.state = new ActiveState();
        this.balance = BigDecimal.ZERO;   // initialize properly
    }

    public Object getLock() {
         return lock;
    }

 
    public String getWalletId() {
        return walletId;
    }

    public String getUserId() {
        return userId;
    }

    public LocalDate getCreatedAt() {
        return createdAt;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void credit(BigDecimal amount) {
        state.credit(this, amount);
    }

    public void debit(BigDecimal amount) {
        state.debit(this, amount);
    }

    public void freeze() {
        state.freeze(this);
    }

    public void activate() {
        state.activate(this);
    }

    public void close() {
        state.close(this);
    }

    public void setState(WalletState state) {
        this.state = state;
    }

    public void addBalance(BigDecimal amount) {
       this.balance = this.balance.add(amount);
    }

    public void subtractBalance(BigDecimal amount) {
        this.balance = this.balance.subtract(amount);
    }

}
