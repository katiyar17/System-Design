package org.walletsystem.model.state;
import org.walletsystem.model.Wallet;
import java.math.BigDecimal;

public class ActiveState implements WalletState{

    @Override
    public void credit(Wallet wallet, BigDecimal amount) {


         validateAmount(amount);
         wallet.addBalance(amount);

    }

    @Override
    public void debit(Wallet wallet, BigDecimal amount) {



        validateAmount(amount);


        if (wallet.getBalance().compareTo(amount) < 0) {
            throw new IllegalStateException("Insufficient balance");
        }
        try {
            Thread.sleep(50);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        wallet.subtractBalance(amount);
    }

    @Override
    public void freeze(Wallet wallet) {
        wallet.setState(new FrozenState());
    }

    @Override
    public void activate(Wallet wallet) {

    }

    @Override
    public void close(Wallet wallet) {
        wallet.setState(new ClosedState());
    }

    private void validateAmount(BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Invalid amount");
        }
    }
}