package org.walletsystem.model.state;

import org.walletsystem.model.Wallet;

import java.math.BigDecimal;

public interface WalletState {

    void credit(Wallet wallet, BigDecimal amount);
    void debit(Wallet wallet, BigDecimal amount);
    void freeze(Wallet wallet);
    void activate(Wallet wallet);
    void close(Wallet wallet);

}
