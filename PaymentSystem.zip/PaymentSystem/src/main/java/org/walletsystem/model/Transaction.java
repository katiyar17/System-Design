package org.walletsystem.model;
import org.walletsystem.enums.TransactionStatus;
import org.walletsystem.enums.TransactionType;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

/*
User (1) ------ (1) Wallet
Wallet (1) ---- (N) Transaction
 */
public class Transaction {

    private final String transactionId;
    private final String transferReferenceId;
    private final String walletId;
    private final LocalDateTime transactionDate;
    private TransactionStatus status;
    private final BigDecimal amount;
    private final TransactionType transactionType;

    public Transaction(String walletId,
                       String transferReferenceId,
                       BigDecimal amount,
                       TransactionType transactionType) {

        if (walletId == null
                || transferReferenceId == null
                || amount == null
                || transactionType == null
                || amount.compareTo(BigDecimal.ZERO) <= 0) {

            throw new IllegalArgumentException("Invalid transaction input");
        }

        this.walletId = walletId;
        this.transferReferenceId = transferReferenceId;
        this.amount = amount;
        this.transactionType = transactionType;
        this.transactionId = UUID.randomUUID().toString();
        this.transactionDate = LocalDateTime.now();
        this.status = TransactionStatus.CREATED; // default
    }

//    public void markSuccess() {
//        if (this.status != TransactionStatus.PENDING) {
//            throw new IllegalStateException("Invalid state transition");
//        }
//        this.status = TransactionStatus.SUCCESS;
//    }
//

    public void markProcessing() {
       if(this.status != TransactionStatus.CREATED) {
           throw new IllegalStateException("Invalid transition to PROCESSING");
       }
        this.status = TransactionStatus.PROCESSING;
    }

    public void markSuccess() {
        if(this.status != TransactionStatus.PROCESSING) {
            throw new IllegalStateException("Invalid transition to SUCCESS");
        }
        this.status = TransactionStatus.SUCCESS;
    }

    public void markFailed() {
        if (this.status != TransactionStatus.PROCESSING) {
            throw new IllegalStateException("Invalid transition to FAILED");
        }
        this.status = TransactionStatus.FAILED;
    }

    public void markReversed() {
        if (this.status != TransactionStatus.SUCCESS) {
            throw new IllegalStateException("Invalid transition to REVERSED");
        }
        this.status = TransactionStatus.REVERSED;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public String getTransferReferenceId() {
        return transferReferenceId;
    }

    public String getWalletId() {
        return walletId;
    }

    public LocalDateTime getTransactionDate() {
        return transactionDate;
    }

    public TransactionStatus getStatus() {
        return status;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public TransactionType getTransactionType() {
        return transactionType;
    }









}
