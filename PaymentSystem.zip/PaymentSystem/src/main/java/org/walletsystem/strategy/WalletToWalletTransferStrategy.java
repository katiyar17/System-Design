package org.walletsystem.strategy;
import org.walletsystem.enums.TransactionType;
import org.walletsystem.event.events.TransactionCompletedEvent;
import org.walletsystem.event.events.TransactionFailedEvent;
import org.walletsystem.event.publisher.EventPublisher;
import org.walletsystem.model.Transaction;
import org.walletsystem.model.Wallet;
import org.walletsystem.repository.TransactionRepository;
import org.walletsystem.repository.WalletRepository;
import org.walletsystem.service.LedgerService;
import java.math.BigDecimal;

public class WalletToWalletTransferStrategy implements TransferStrategy{


    private final TransactionRepository transactionRepository;
    private final LedgerService ledgerService;
    private final EventPublisher publisher;

    public WalletToWalletTransferStrategy(WalletRepository walletRepository, TransactionRepository transactionRepository, LedgerService ledgerService, EventPublisher publisher) {

        this.transactionRepository = transactionRepository;
        this.ledgerService = ledgerService;
        this.publisher = publisher;
    }

    @Override
    public void transfer(Wallet senderWallet, Wallet receiverWallet, BigDecimal amount, String transferRefId) {

        Transaction debitTransaction = new Transaction(senderWallet.getWalletId(),transferRefId,amount,
                TransactionType.DEBIT);

        Transaction creditTransaction = new Transaction(receiverWallet.getWalletId(),transferRefId,amount,
                TransactionType.CREDIT);

        transactionRepository.save(debitTransaction);
        transactionRepository.save(creditTransaction);

        debitTransaction.markProcessing();
        creditTransaction.markProcessing();

        ledgerService.recordEntry(senderWallet.getWalletId(),debitTransaction.getTransactionId(),amount,
                TransactionType.DEBIT);

        ledgerService.recordEntry(receiverWallet.getWalletId(),creditTransaction.getTransactionId(),amount,
                TransactionType.CREDIT);

        boolean debited = false;

        try {

            senderWallet.debit(amount);
            debited = true;
            receiverWallet.credit(amount);
            debitTransaction.markSuccess();
            creditTransaction.markSuccess();
            publisher.publish(new TransactionCompletedEvent(transferRefId,senderWallet.getWalletId(),
                    receiverWallet.getWalletId(),amount));
        } catch (Exception e) {
            if (debited) {
                senderWallet.credit(amount);
            }
            debitTransaction.markFailed();
            creditTransaction.markFailed();
            try {
                publisher.publish(
                        new TransactionFailedEvent(
                                transferRefId,
                                senderWallet.getWalletId(),
                                receiverWallet.getWalletId(),
                                amount,
                                e.getMessage()
                        )
                );
            } catch (Exception ex) {
                System.out.println("Event publish failed");
            }
            throw e;
        }
    }
}