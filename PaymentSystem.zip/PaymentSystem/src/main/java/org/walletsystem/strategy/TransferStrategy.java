package org.walletsystem.strategy;
import org.walletsystem.model.Wallet;
import java.math.BigDecimal;

public interface TransferStrategy {

    void transfer(Wallet fromWallet, Wallet toWallet, BigDecimal amount,String transferRefId);

}
