//package org.walletsystem;
//import org.walletsystem.factory.TransferStrategyFactory;
//import org.walletsystem.model.Wallet;
//import org.walletsystem.repository.*;
//import org.walletsystem.service.IdempotencyService;
//import org.walletsystem.service.LedgerService;
//import org.walletsystem.service.TransactionManager;
//import org.walletsystem.service.WalletService;
//import org.walletsystem.model.Transaction;
//import java.math.BigDecimal;
//import java.util.List;
//import java.util.UUID;
//
//public class Main {
//
//    public static void main(String[] args) {
//
//        WalletRepository walletRepository = new InMemoryWalletRepository();
//        LedgerRepository ledgerRepository = new InMemoryLedgerRepository();
//        LedgerService ledgerService = new LedgerService(ledgerRepository);
//
//        TransactionRepository transactionRepository = new InMemoryTransactionRepository();
//        TransferStrategyFactory transferStrategyFactory = new TransferStrategyFactory(walletRepository,transactionRepository
//                ,ledgerService);
//
//        IdempotencyService idempotencyService = new IdempotencyService();
//
//
//        TransactionManager transactionManager =
//                new TransactionManager(walletRepository,transactionRepository,ledgerService,transferStrategyFactory);
//
//        WalletService walletService =
//                new WalletService(walletRepository, idempotencyService, transactionRepository,
//                        ledgerService, transactionManager);
//
//        // Create wallets
//        String walletA = walletService.createWallet("userA");
//        String walletB = walletService.createWallet("userB");
//
//        // Add money to A
//        // walletService.credit(walletA, new BigDecimal("1000"));
//        walletService.deposit(walletA,new BigDecimal("1000"));
//        System.out.println("/n" + ledgerRepository.findByWalletId(walletA));
//
//        System.out.println("Initial Balance A: "
//                + walletRepository.findById(walletA).get().getBalance());
//
//        System.out.println("Initial Balance B: "
//                + walletRepository.findById(walletB).get().getBalance());
//
//        // Transfer money
//        String requestId = UUID.randomUUID().toString();
//
//        System.out.println("\nFirst transfer attempt");
//        walletService.transfer(walletA, walletB, new BigDecimal("800"), requestId);
//        System.out.println("remaining amount of A after deduction = " + " " + walletRepository.findById(walletA).get().getBalance());
//        System.out.println("current balance of B after credit from A = " + " " + walletRepository.findById(walletB).get().getBalance());
//
//        System.out.println("\nSecond transfer attempt");
//        System.out.println("Retry transfer with same requestId");
//        String transferRef = walletService.transfer(
//                walletA,
//                walletB,
//                new BigDecimal("300"),
//                requestId
//        );
//
//
//        System.out.println("Final Balance A after retry: "
//                + walletRepository.findById(walletA).get().getBalance());
//
//        System.out.println("Final Balance B after retry: "
//                + walletRepository.findById(walletB).get().getBalance());
//
//        System.out.println("\nTransactions for Wallet A:");
//
//        List<Transaction> transactions =
//                transactionRepository.findByWalletId(walletA);
//
//        for (Transaction t : transactions) {
//            System.out.println(
//                    ""+"Type: " + t.getTransactionType()
//                            + " Amount: " + t.getAmount()
//            );
//        }
//
//        System.out.println("\n" + ledgerRepository.findByWalletId(walletA));
//        System.out.println(ledgerRepository.findByWalletId(walletB));
//
////        System.out.println("\nBalances before reversal:");
////        System.out.println("A = " + walletRepository.findById(walletA).get().getBalance());
////        System.out.println("B = " + walletRepository.findById(walletB).get().getBalance());
////
////        System.out.println("\nReversing transaction...");
////        walletService.reverseTransaction(transferRef);
////
////        System.out.println("\nBalances after reversal:");
////        System.out.println("A = " + walletRepository.findById(walletA).get().getBalance());
////        System.out.println("B = " + walletRepository.findById(walletB).get().getBalance());
//
//
//
//
//
//
//
//    }
//}

package org.walletsystem;
import org.walletsystem.event.events.TransactionCompletedEvent;
import org.walletsystem.event.events.TransactionFailedEvent;
import org.walletsystem.event.listener.TransactionAuditListener;
import org.walletsystem.event.listener.TransactionFailedListener;
import org.walletsystem.event.listener.TransactionFailedListener;
import org.walletsystem.event.publisher.EventPublisher;
import org.walletsystem.factory.TransferStrategyFactory;
import org.walletsystem.model.Wallet;
import org.walletsystem.repository.*;
import org.walletsystem.service.IdempotencyService;
import org.walletsystem.service.LedgerService;
import org.walletsystem.service.TransactionManager;
import org.walletsystem.service.WalletService;

import java.math.BigDecimal;
import java.util.UUID;

public class Main {
    public static void main(String[] args) {

        WalletRepository walletRepository = new InMemoryWalletRepository();
        LedgerRepository ledgerRepository = new InMemoryLedgerRepository();
        LedgerService ledgerService = new LedgerService(ledgerRepository);

        EventPublisher publisher = EventPublisher.getInstance();
        publisher.register(TransactionCompletedEvent.class,new TransactionAuditListener());
        publisher.register(TransactionFailedEvent.class,new TransactionFailedListener());


        TransactionRepository transactionRepository = new InMemoryTransactionRepository();
        TransferStrategyFactory transferStrategyFactory =
                new TransferStrategyFactory(walletRepository, transactionRepository, ledgerService, publisher);

        IdempotencyService idempotencyService = new IdempotencyService();

        TransactionManager transactionManager =
                new TransactionManager(walletRepository, transactionRepository, ledgerService, transferStrategyFactory);

        WalletService walletService =
                new WalletService(walletRepository, idempotencyService, transactionRepository,
                        ledgerService, transactionManager);



        // Create wallets
        String walletA = walletService.createWallet("userA");
        String walletB = walletService.createWallet("userB");

        // Deposit money
        walletService.deposit(walletA, new BigDecimal("1000"));

        System.out.println("Initial Balance A: "
                + walletRepository.findById(walletA).get().getBalance());
        System.out.println("Initial Balance B: "
                + walletRepository.findById(walletB).get().getBalance());

        System.out.println("\n=== START TRANSFER ===");

        walletService.transfer(
                walletA,
                walletB,
                new BigDecimal("5000"),
                UUID.randomUUID().toString()
        );

        System.out.println("=== END TRANSFER ===");

        // 🔥 CONCURRENCY TEST
//        Runnable task = () -> {
//            try {
//                walletService.transfer(
//                        walletA,
//                        walletB,
//                        new BigDecimal("800"),
//                        UUID.randomUUID().toString() // different requestId to bypass idempotency
//                );
//            } catch (Exception e) {
//                System.out.println("Transfer failed: " + e.getMessage());
//            }
//        };
//
//        Thread t1 = new Thread(task);
//        Thread t2 = new Thread(task);
//
//        t1.start();
//        t2.start();
//
//        try {
//            t1.join();
//            t2.join();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
        System.out.println("\nFinal Balance A: "
                + walletRepository.findById(walletA).get().getBalance());

        System.out.println("Final Balance B: "
                + walletRepository.findById(walletB).get().getBalance());
    }

}
