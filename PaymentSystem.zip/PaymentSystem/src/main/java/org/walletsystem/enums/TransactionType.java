package org.walletsystem.enums;

public enum TransactionType {
    CREDIT,
    DEBIT
}
