package org.walletsystem.enums;

public enum TransferType {
    WALLET_TO_BANK,
    WALLET_TO_UPI,
    WALLET_TO_WALLET
}
