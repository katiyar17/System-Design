package org.walletsystem.enums;

public enum TransactionStatus {
    CREATED,
    PROCESSING,
    SUCCESS,
    FAILED,
    REVERSED
}