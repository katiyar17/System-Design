package org.walletsystem.repository;
import org.walletsystem.model.LedgerEntry;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class InMemoryLedgerRepository implements LedgerRepository{

    private final Map<String, List<LedgerEntry>> ledgerStore = new ConcurrentHashMap<>();

    @Override
    public void save(LedgerEntry entry) {
        ledgerStore
                .computeIfAbsent(entry.getWalletId(), k -> new ArrayList<>())
                .add(entry);
    }

    @Override
    public List<LedgerEntry> findByWalletId(String walletId) {
        return  ledgerStore.getOrDefault(walletId, new ArrayList<>());
    }

    public void printAllLogs() {
        ledgerStore.forEach((walletId, entries) -> {
            System.out.println("Wallet ID: " + walletId);
            entries.forEach(entry -> System.out.println(" - " + entry));
        });
    }

}
