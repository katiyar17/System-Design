package org.walletsystem.repository;

import org.walletsystem.model.LedgerEntry;
import org.walletsystem.model.Transaction;

import java.util.List;

public interface LedgerRepository {

     void save(LedgerEntry entry);
     List<LedgerEntry> findByWalletId(String walletId);

}
