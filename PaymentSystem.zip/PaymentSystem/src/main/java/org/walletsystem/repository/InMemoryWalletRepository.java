package org.walletsystem.repository;
import org.walletsystem.model.Wallet;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class InMemoryWalletRepository implements WalletRepository {

    Map<String, Wallet> walletMap = new ConcurrentHashMap<>();

    @Override
    public void save(Wallet wallet) {
        walletMap.put(wallet.getWalletId(), wallet);
    }

    @Override
    public Optional<Wallet> findById(String walletId) {
         return Optional.ofNullable(walletMap.get(walletId));
    }

}
