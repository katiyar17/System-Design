package org.walletsystem.repository;
import org.walletsystem.model.Transaction;
import java.util.List;
import java.util.Optional;

public interface TransactionRepository {

    public void save(Transaction transaction);
    public  List<Transaction> findByWalletId(String walletId);
    public  List<Transaction> findByTransferRefId(String refId);

}
