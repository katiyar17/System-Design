package org.walletsystem.repository;
import org.walletsystem.model.Wallet;
import java.util.Optional;
public interface WalletRepository {

    public void save(Wallet wallet);
    public Optional<Wallet> findById(String walletId);

}

    /*
    sender wallet
    recerver wallet
    Generate transferReferenceId
    sender amount
     check of valid amt from sender
     check for availb baln in sender account
     then perform debit
     subtract bal from sender
     then add amount in recever account
     perform credit
     increate his amount in his wallet

     exceptions thinking i mean if debit succ and credit fails => use try and catch and only if debit uscc
     reollback after detecting this. but multiple req can come on wallet so we to lock or not

     Very Important: Deadlock Risk

If:

Thread 1:

locks A

tries to lock B

Thread 2:

locks B

tries to lock A

Deadlock.

So we must lock in consistent order.

Wallet firstLock = senderId.compareTo(receiverId) < 0 ? sender : receiver;
Wallet secondLock = senderId.compareTo(receiverId) < 0 ? receiver : sender;

synchronized (firstLock) {
    synchronized (secondLock) {
        // perform debit + credit
    }
}



      */

