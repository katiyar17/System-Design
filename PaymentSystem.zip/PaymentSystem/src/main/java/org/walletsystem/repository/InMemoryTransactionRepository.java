package org.walletsystem.repository;
import org.walletsystem.model.Transaction;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class InMemoryTransactionRepository implements TransactionRepository {

    Map<String, Transaction> transactionMap = new ConcurrentHashMap<>();

    @Override
    public void save(Transaction transaction) {
        transactionMap.put(transaction.getTransactionId(), transaction);
    }



    @Override
    public List<Transaction> findByWalletId(String walletId) {
        List<Transaction> transactions = new ArrayList<>();
        for(Transaction t : transactionMap.values()) {
            if (t.getWalletId().equalsIgnoreCase(walletId)) {
                transactions.add(t);
            }
        }
        return transactions;
    }

    @Override
    public List<Transaction> findByTransferRefId(String refId) {

        List<Transaction> result = new ArrayList<>();

        for (Transaction t : transactionMap.values()) {
            if (t.getTransferReferenceId().equals(refId)) {
                result.add(t);
            }
        }

        return result;
    }
}
