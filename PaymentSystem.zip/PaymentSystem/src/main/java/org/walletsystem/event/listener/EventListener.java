package org.walletsystem.event.listener;
import org.walletsystem.event.events.Event;

public interface EventListener<T extends Event> {
     void handle(T event);
}