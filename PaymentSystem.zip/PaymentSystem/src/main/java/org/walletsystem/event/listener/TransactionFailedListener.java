package org.walletsystem.event.listener;
import org.walletsystem.event.events.TransactionFailedEvent;

public class TransactionFailedListener implements EventListener<TransactionFailedEvent> {

    @Override
    public void handle(TransactionFailedEvent event) {
        System.out.println(
                "FAILED AUDIT LOG → TransactionId: " + event.getTransactionId() +
                        ", From: " + event.getSenderWalletId() +
                        ", To: " + event.getReceiverWalletId() +
                        ", Amount: " + event.getAmount() +
                        ", Time: " + event.getTimestamp() +
                        ", Failure Reason: " + event.getFailureReason()
        );
    }
}
