package org.walletsystem.event.events;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

public class TransactionCompletedEvent implements Event {

    private final String eventId;
    private final String transactionId;
    private final String senderWalletId;
    private final String receiverWalletId;
    private final BigDecimal amount;
    private final LocalDateTime timestamp;

    public TransactionCompletedEvent(String transactionId,
                                     String senderWalletId,
                                     String receiverWalletId,
                                     BigDecimal amount) {
        this.eventId = UUID.randomUUID().toString();
        this.transactionId = transactionId;
        this.senderWalletId = senderWalletId;
        this.receiverWalletId = receiverWalletId;
        this.amount = amount;
        this.timestamp = LocalDateTime.now();
    }

    @Override
    public String getEventId() {
        return eventId;
    }

    @Override
    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public String getSenderWalletId() {
        return senderWalletId;
    }

    public String getReceiverWalletId() {
        return receiverWalletId;
    }

    public BigDecimal getAmount() {
        return amount;
    }
}