package org.walletsystem.event.listener;
import org.walletsystem.event.events.TransactionCompletedEvent;

public class TransactionAuditListener implements EventListener<TransactionCompletedEvent> {

    @Override
    public void handle(TransactionCompletedEvent event) {
        System.out.println(
                "SUCCESS AUDIT LOG → TransactionId: " + event.getTransactionId() +
                        ", From: " + event.getSenderWalletId() +
                        ", To: " + event.getReceiverWalletId() +
                        ", Amount: " + event.getAmount() +
                        ", Time: " + event.getTimestamp()
        );
    }
}
