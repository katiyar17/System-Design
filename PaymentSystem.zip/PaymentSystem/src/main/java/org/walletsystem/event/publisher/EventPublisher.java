package org.walletsystem.event.publisher;
import org.walletsystem.event.events.Event;
import org.walletsystem.event.listener.EventListener;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EventPublisher {

    private final Map<Class<? extends Event>, List<EventListener<? extends Event>>> listeners = new HashMap<>();
    private final ExecutorService executor = Executors.newFixedThreadPool(5);
    private static final EventPublisher INSTANCE = new EventPublisher();

    private EventPublisher() {}   // private constructor

    public static EventPublisher getInstance() {
        return INSTANCE;
    }

     public <T extends Event> void register(Class<T> eventType, EventListener<T> listener) {

         listeners
                 .computeIfAbsent(eventType, k-> new ArrayList<>())
                 .add(listener);
     }

     // publish event
    //Take an event and notify all listeners
    @SuppressWarnings("unchecked")
    public <T extends Event> void publish(T event) {

         List<EventListener<? extends Event>> eventListeners =
                 listeners.getOrDefault(event.getClass(), Collections.emptyList());

        for (EventListener listener : eventListeners) {
            executor.submit(() -> {
                try {
                    listener.handle(event);
                } catch (Exception e) {
                    System.out.println("Listener failed: " + e.getMessage());
                }
            });
        }
    }

}

/*
? extends Event
“Any class that is a child of Event”
*/