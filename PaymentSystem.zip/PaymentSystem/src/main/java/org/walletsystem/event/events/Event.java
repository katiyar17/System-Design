package org.walletsystem.event.events;
import java.time.LocalDateTime;
import java.time.LocalTime;

public interface Event {
    String getEventId();
    LocalDateTime getTimestamp();
}
