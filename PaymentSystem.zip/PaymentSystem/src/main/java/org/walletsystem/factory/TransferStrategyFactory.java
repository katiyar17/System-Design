package org.walletsystem.factory;
import org.walletsystem.enums.TransferType;
import org.walletsystem.event.publisher.EventPublisher;
import org.walletsystem.repository.TransactionRepository;
import org.walletsystem.repository.WalletRepository;
import org.walletsystem.service.LedgerService;
import org.walletsystem.strategy.TransferStrategy;
import org.walletsystem.strategy.WalletToWalletTransferStrategy;


public class TransferStrategyFactory {

    private final WalletRepository walletRepository;
    private final TransactionRepository transactionRepository;
    private final LedgerService ledgerService;
    private final EventPublisher publisher;

    public TransferStrategyFactory(WalletRepository walletRepository, TransactionRepository transactionRepository, LedgerService ledgerService, EventPublisher publisher) {
        this.walletRepository = walletRepository;
        this.transactionRepository = transactionRepository;
        this.ledgerService = ledgerService;
        this.publisher = publisher;
    }

    public TransferStrategy getStrategy(TransferType type) {
        if (type == TransferType.WALLET_TO_WALLET) {
            return new WalletToWalletTransferStrategy(walletRepository, transactionRepository, ledgerService,publisher);
        }
            throw new IllegalArgumentException("Unsupported transfer type: " + type);
    }
}
